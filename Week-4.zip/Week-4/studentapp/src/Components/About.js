import React, { Component } from 'react';

export class About extends Component {
  render() {
    return (
      <div>
        <h3>Welcome to the About page of the Student Management Portal</h3>
      </div>
    );
  }
}

export default About;